##part 01
##Importing data set
setwd("C:\\Users\\it24101843\\Desktop\\it24101843\\Lab 4")

##Importing the data set
data <-read.table("DATA 4.txt",header=TRUE, sep = "")
## View the file in a separate window
fix(data)
attach(data)
##PART 2
##PART(a)
##obtaining box plots

boxplot(X1,main="Box Plot for team Attendance" , outline = TRUE, outpc=8,horizontal=TRUE)
boxplot(X2,main="Box Plot for team salary" , outline = TRUE, outpc=8,horizontal=TRUE)
boxplot(X3,main="Box Plot for years" , outline = TRUE, outpc=8,horizontal=TRUE)

##obtaining histogram
hist(X1,ylab="Frequency",xlab="Team Attendence", main="Histogram for Team Attendence")
hist(X2,ylab="Frequency",xlab="Team salary", main="Histogram for Team salary")
hist(X3,ylab="Frequency",xlab="Years", main="Histogram for Years")

#Stem & Leaf Plot
stem(X1)
stem(X2)
stem(X3)

# Mean
mean(X1) 
mean(X2) 
mean(X3)

# Median
median(X1) 
median(X2)
median(X3)

# Standard Deviation
sd(X1)
sd(X2)
sd(X3)

# Quartiles
quantile(X1, c(0.25, 0.75))
quantile(X2, c(0.25, 0.75))
quantile(X3, c(0.25, 0.75))

# IQR
IQR(X1)
IQR(X2)
IQR(X3)


## Part (c) - Summary Statistics in R

# Getting five-number summary along with mean for variables X1, X2, and X3
summary(X1)
summary(X2)
summary(X3)

# Getting only the five-number summary for X1
quantile(X1)

# Accessing specific quartiles of X1
first_quartile <- quantile(X1)[2]   
third_quartile <- quantile(X1)[4]   

# Displaying the quartiles
print(paste("First Quartile (Q1):", first_quartile))
print(paste("Third Quartile (Q3):", third_quartile))

## Part 3 - Function to Get Mode of a Dataset

# Define the mode function
get.mode <- function(y) {
  counts <- table(y)                          # Frequency table
  mode_value <- names(counts[counts == max(counts)])  # Extract mode(s)
  return(mode_value)
}

# Example: Obtaining the mode of variable X3
mode_X3 <- get.mode(X3)
print(paste("Mode of X3:", mode_X3))

## Breakdown of the logic (for understanding)
# Frequency table
table(X3)

# Maximum frequency
max(table(X3))

# Logical check for max frequency
table(X3) == max(table(X3))

# Extract value(s) with max frequency
table(X3)[table(X3) == max(table(X3))]

# Extract name(s) of those values (i.e., the mode)
names(table(X3)[table(X3) == max(table(X3))])


## Part 4 - Function to Detect Outliers Using IQR

# Define the outlier detection function
get.outliers <- function(z) {
  q1 <- quantile(z)[2]           # First quartile (Q1)
  q3 <- quantile(z)[4]           # Third quartile (Q3)
  iqr <- q3 - q1                 # Interquartile range
  
  ub <- q3 + 1.5 * iqr           # Upper bound
  lb <- q1 - 1.5 * iqr           # Lower bound
  
  # Print bounds and outliers
  print(paste("Upper Bound =", ub))
  print(paste("Lower Bound =", lb))
  outliers <- sort(z[z < lb | z > ub])
  print(paste("Outliers:", paste(outliers, collapse = ", ")))
}

# Apply the function to each variable
get.outliers(X1)
get.outliers(X2)
get.outliers(X3)



##
## Step 1: Import the dataset
branch_data <- read.table("Exercise.txt", header = TRUE, sep = "\t")
print("Dataset successfully imported.")
head(branch_data)

## Step 2: Identify variable types and scales
str(branch_data)

# You can also manually annotate:
# - Team: Categorical (Nominal)
# - Team Attendance (X1): Numeric (Ratio)
# - Team Salary (X2): Numeric (Ratio)
# - Years (X3): Numeric (Ratio)

## Step 3: Boxplot for Sales (assuming 'Sales' is a column in Exercise.txt)
boxplot(branch_data$Sales, main = "Boxplot of Sales", col = "lightblue", border = "darkblue")

# Interpretation (for your Word doc):
# If the box is symmetric → roughly normal distribution.
# If skewed left/right → distribution is skewed.
# Presence of dots → outliers.

## Step 4: Five-number summary and IQR for Advertising
summary(branch_data$Advertising)
quantile(branch_data$Advertising)
IQR(branch_data$Advertising)

## Step 5: Function to detect outliers in a numeric vector
get.outliers <- function(x) {
  q1 <- quantile(x)[2]
  q3 <- quantile(x)[4]
  iqr <- q3 - q1
  lb <- q1 - 1.5 * iqr
  ub <- q3 + 1.5 * iqr
  outliers <- sort(x[x < lb | x > ub])
  
  print(paste("Lower Bound =", lb))
  print(paste("Upper Bound =", ub))
  print(paste("Outliers:", paste(outliers, collapse = ", ")))
}

# Check for outliers in Years variable
get.outliers(branch_data$Years)
